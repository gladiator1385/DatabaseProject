CREATE TABLE `cases` (
  `case_id` int NOT NULL AUTO_INCREMENT ,
  `criminal_id` varchar(19) NOT NULL ,
  `crime_id` int NOT NULL ,
  `name_` varchar(120) NOT NULL ,
  `hometown` varchar(120) NOT NULL ,
  `term` int NOT NULL ,
  PRIMARY KEY (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `cases` VALUES (null, '310116198702154037', 1,"范冰冰","Shanghai",183);
INSERT INTO `cases` VALUES (null, '510283746372837463', 2,"Donald Trump","New York",3658);
INSERT INTO `cases` VALUES (null, '234736272737263663', 3,"Barack Obama","Washington D.C.",1238);
INSERT INTO `cases` VALUES (null, '354626253545683729', 4,"Moon jae-in","South Korea",180);

DELIMITER $$

CREATE TRIGGER cases_insert 
BEFORE INSERT ON cases
    FOR EACH ROW
     BEGIN 
         IF NEW.criminal_id NOT IN (select criminal_id from criminals) THEN
             INSERT INTO criminals values(NEW.criminal_id,NEW.name_,NEW.hometown);
		END IF;
	END$$
DELIMITER ;
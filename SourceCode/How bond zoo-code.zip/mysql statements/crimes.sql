CREATE TABLE `crimes` (
  `crime_id` int NOT NULL AUTO_INCREMENT ,
  `crime` varchar(19) NOT NULL ,
  PRIMARY KEY (`crime_id`),
  UNIQUE (`crime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `crimes` VALUES (null, "Bribery");
INSERT INTO `crimes` VALUES (null, "Nuisance");
INSERT INTO `crimes` VALUES (null, "Slandering");
INSERT INTO `crimes` VALUES (null, "Fraud");
INSERT INTO `crimes` VALUES (null, "Gambling");
INSERT INTO `crimes` VALUES (null, "Drug abusing");
INSERT INTO `crimes` VALUES (null, "Money laundry");
INSERT INTO `crimes` VALUES (null, "Sex-harassment");
INSERT INTO `crimes` VALUES (null, "Theft");
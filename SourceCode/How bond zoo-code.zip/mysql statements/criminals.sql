CREATE TABLE `criminals` (
  `criminal_id` varchar(19) NOT NULL ,
  `name` varchar(120) NOT NULL ,
  `hometown` varchar(120) NOT NULL ,
  PRIMARY KEY (`criminal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `criminals` VALUES ( '310116198702154037', "范冰冰","Shanghai");
INSERT INTO `criminals` VALUES ( '510283746372837463', "Donald Trump","New York");
INSERT INTO `criminals` VALUES ( '234736272737263663', "Barack Obama","Washington D.C.");
INSERT INTO `criminals` VALUES ( '354626253545683729', "Moon jae-in","South Korea");

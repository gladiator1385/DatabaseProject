//"¼�밸���ļ�����"


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;


public class AddCaseListener implements ActionListener{
    JTextField F1,F2,F3,F4,F5;
    Connection conn_;
    JFrame parent_;
    
    void set_fields(JTextField a,JTextField b,JTextField c,JTextField d,JTextField e) {
    	F1=a;
    	F2=b;
    	F3=c;
    	F4=d;
    	F5=e;
    }
    
    void setConnection(Connection conn) {
    	conn_=conn;
    }
    
    void setParent(JFrame p) {
    	parent_=p;
    }
    
    public void actionPerformed(ActionEvent f) {
    	Statement sql;
    	try {
    		sql=conn_.createStatement();
    		sql.executeUpdate("insert into cases values (null,'"+F1.getText()+"',"+F2.getText()+",'"+F3.getText()+"','"+F4.getText()+"',"+F5.getText()+");");
    		JOptionPane.showMessageDialog(parent_, "Successfully��","Status",1);
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
}

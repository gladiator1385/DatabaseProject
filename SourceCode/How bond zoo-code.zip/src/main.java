import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.*;
import java.awt.*;
import java.io.*;


public class main {
    private static String url="jdbc:mysql://localhost:3306/criminal_management";
    private static String user="root";
    private static String password="swu20200920";
    Connection con;
    
    
    
	public static void main(String[] args) {
		Connection con;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url, user, password);
			MainWindow win_=new MainWindow(con);
			win_.setVisible(true);
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
    
}


